// suma.test.js
const producto = require('./suma');

test('2*2=4', () => {
  expect(producto(2, 2)).toBe(4);
});

test('-1*1=-1', () => {
  expect(producto(-1, 1)).toBe(-1);
});

test('0.1*0.2=0.02', () => {
  expect(producto(0.1, 0.2)).toBeCloseTo(0.02);
});

test('producto de números grandes', () => {
  expect(producto(10000, 10000)).toBe(100000000);
});

